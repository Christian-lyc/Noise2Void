This is a DQN code for classification by cropping to zoom in images.
